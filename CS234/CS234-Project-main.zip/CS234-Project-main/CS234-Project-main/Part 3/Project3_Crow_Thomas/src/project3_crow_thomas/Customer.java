package project3_crow_thomas;

import java.util.*;
import java.time.format.*;
import java.time.LocalDateTime;




public class Customer {


//  Declare instance variables
    Scanner scan = new Scanner(System.in);
    private String customerName;
    private String customerAddress;
    private String customerPhone;
    private String customerEmail;
    private ArrayList<Appointment> customerAppointments = new ArrayList<Appointment>();
    private ArrayList<Vehicle> customerVehicles = new ArrayList<Vehicle>();

//Default constructor

    public Customer(String customerName, String customerAddress, String customerPhone, String customerEmail ) {
        
        modifyCustomerName(customerName);
        modifyCustomerAddress(customerAddress);
        modifyCustomerPhone(customerPhone);
        modifyCustomerEmail(customerEmail);

    }

//  Method: getCustomerName()
//  Purpose: Get the customer's name
//  Arguments:  None  
//  Returns:    The customer's name as a string value

    public String getCustomerName() {
        return this.customerName;
    }

//  Method: getCustomerAddresss()
//  Purpose: Get the customer's address
//  Arguments:  None  
//  Returns:    The customer's address as a string value

    public String getCustomerAddress() {
        return this.customerAddress;
    }

//  Method: getCustomerPhone()
//  Purpose: Get the customer's phone number
//  Arguments:  None  
//  Returns:    The customer's phone number as a string value

    public String getCustomerPhone() {
        return this.customerPhone;
    }

//  Method: getCustomerAddresss()
//  Purpose: Get the customer's email address
//  Arguments:  None  
//  Returns:    The customer's email address as a string value

    public String getCustomerEmail() {
        return this.customerEmail;
    }

//  Method: modifyCustomerName()
//  Purpose: Change the customer's name
//  Arguments:  The customer's name as a string value 
//  Returns:    None

    public void modifyCustomerName(String customerName) {
        this.customerName =customerName;
    }

//  Method: modifyCustomerAddress()
//  Purpose: Change the customer's address
//  Arguments:  The customer's address as a string value 
//  Returns:    None

    public void modifyCustomerAddress(String customerAddress) {
        this.customerAddress =customerAddress;
    }

//  Method: modifyCustomerPhone()
//  Purpose: Change the customer's phone number
//  Arguments:  The customer's phone number as a string value 
//  Returns:    None

    public void modifyCustomerPhone(String customerPhone) {
        this.customerPhone = customerPhone;
    }

//  Method: modifyCustomerName()
//  Purpose: Change the customer's name
//  Arguments:  The customer's name as a string value 
//  Returns:    None

    public void modifyCustomerEmail(String customerEmail) {
        this.customerEmail = customerEmail;
    }

    public void showCustomerInfo() {
 
        System.out.println(this.getCustomerName() + "\t|\t " + this.getCustomerAddress() + "\t|\t " + this.getCustomerPhone() + "\t|\t " + this.getCustomerEmail());
        
    }



//  Method: addCustomerVehicle()
//  Purpose: Add a vehicle the customer owns
//  Arguments: The vehicle as a vehicle value
//  Returns: None

    public void addCustomerVehicle(String vehicleBrand, String vehicleModel, String vehicleYear, String vehicleMileage) {
        
        Vehicle customerVehicle = new Vehicle(vehicleBrand, vehicleModel, vehicleYear, vehicleMileage);
        customerVehicles.add(customerVehicle);
    }

//  Method: showCustomerVehicles()
//  Purpose: Show the vehicles the customer owns
//  Arguments: None
//  Returns: None

    public void showCustomerVehicles() {

        Vehicle customerVehicle;

        System.out.println("   Year\t|\tBrand\t|\tModel\t\t|\tMileage\n");
        for (int i = 0; i < this.customerVehicles.size(); i++ ) {
            customerVehicle = this.customerVehicles.get(i);
            System.out.println("#" + (i+1) + " " + customerVehicle.getVehicleYear() + "\t|\t" + customerVehicle.getVehicleBrand() + "\t|\t" + customerVehicle.getVehicleModel() + "\t\t|\t" + customerVehicle.getVehicleMileage());
        }
    }

//  Method: getCustomerVehicleBrand()
//  Purpose: 
//  Arguments: 
//  Returns: 

    public String getCustomerVehicleBrand(int customerVehicleElement) {
        return this.customerVehicles.get(customerVehicleElement).getVehicleBrand();
    }

//  Method: setCustomerVehicleBrand()
//  Purpose: 
//  Arguments: 
//  Returns: 

public void setCustomerVehicleBrand(int customerVehicleElement, String vehicleBrand) {
    this.customerVehicles.get(customerVehicleElement).setVehicleBrand(vehicleBrand);
}

//  Method: getCustomerVehicleModel()
//  Purpose: 
//  Arguments: 
//  Returns: 

    public String getCustomerVehicleModel(int customerVehicleElement) {
        return this.customerVehicles.get(customerVehicleElement).getVehicleModel();
    }

//  Method: setCustomerVehicleModel()
//  Purpose: 
//  Arguments: 
//  Returns: 

    public void setCustomerVehicleModel(int customerVehicleElement, String vehicleModel) {
        this.customerVehicles.get(customerVehicleElement).setVehicleModel(vehicleModel);
    }

//  Method: getCustomerVehicleYear()
//  Purpose: 
//  Arguments: 
//  Returns: 

public String getCustomerVehicleYear(int customerVehicleElement) {
    return this.customerVehicles.get(customerVehicleElement).getVehicleYear();
}

//  Method: setCustomerVehicleYear()
//  Purpose: 
//  Arguments: 
//  Returns: 

public void setCustomerVehicleYear(int customerVehicleElement, String vehicleYear) {
this.customerVehicles.get(customerVehicleElement).setVehicleYear(vehicleYear);
}

//  Method: getCustomerVehicleMileage()
//  Purpose: 
//  Arguments: 
//  Returns: 

public String getCustomerVehicleMileage(int customerVehicleElement) {
    return this.customerVehicles.get(customerVehicleElement).getVehicleMileage();
}

//  Method: setCustomerVehicleMileage()
//  Purpose: 
//  Arguments: 
//  Returns: 

public void setCustomerVehicleMileage(int customerVehicleElement, String vehicleMileage) {
this.customerVehicles.get(customerVehicleElement).setVehicleMileage(vehicleMileage);
}    

//  Method: removeCustomerVehicle()
//  Purpose: Remove a vehicle from the the list of customer owned vehicles
//  Arguments: The vehicle as a vehicle value
//  Returns: None

    public void removeCustomerVehicle(int customerVehicleElement) {
        
        this.customerVehicles.remove(customerVehicleElement);
    }

//  Method: addCustomerAppointment()
//  Purpose: Add a customer appointment
//  Arguments: Appointment date as a localdatetime, Service requested as a string value
//  Returns: None

    public void addCustomerAppointment(LocalDateTime appointmentDate, String serviceRequested) {

        Appointment customerAppointment = new Appointment(appointmentDate, serviceRequested);
        customerAppointments.add(customerAppointment);
    }

//  Method: removeCustomerAppointment()
//  Purpose: Add a customer appointment
//  Arguments: The index value of the appointment to be removed as an integer
//  Returns: None

    public void removeCustomerAppointment(int customerElement) {
        customerAppointments.remove(customerElement);
        
    }

//  Method: getustomerAppointmentTime()
//  Purpose: Add a customer appointment
//  Arguments: The index value of the appointment to be removed as an integer
//  Returns: None

    public String getCustomerAppointmentTime(int customerElement) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("KK-dd-yyyy HH:mm a");
        return this.customerAppointments.get(customerElement).getAppointmentTime().format(formatter);
        
    }

//  Method: getustomerAppointmentTime()
//  Purpose: Add a customer appointment
//  Arguments: The index value of the appointment to be removed as an integer
//  Returns: None

    public void modifyCustomerAppointmentTime(LocalDateTime appointmentDate, int customerElement) {
        this.customerAppointments.get(customerElement).modifyAppointmentTime(appointmentDate);
        
    }

//  Method: addCustomerAppointment()
//  Purpose: Add a customer appointment
//  Arguments: Appointment date as a localdatetime, Service requested as a string value
//  Returns: None

    public void showCustomerAppointments() {

        Appointment customerAppointment;
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("KK-dd-yyyy HH:mm a");

        System.out.println("Time\t\t\t|\tService requested\n");
        for (int i = 0; i < this.customerAppointments.size(); i++ ) {
            customerAppointment = this.customerAppointments.get(i);
            if (customerAppointment.getAppointmentTime().isAfter(LocalDateTime.now())) {
                System.out.println("#" + (i+1) + ": " + customerAppointment.getAppointmentTime().format(formatter) + "\t|\t" + customerAppointment.getServiceRequested());
                System.out.println();
            }
            else {
                System.out.println("No upcoming appointments found");
            }
        }
    }

//  Method: getCustomerAppointmentService
//  Purpose: 
//  Arguments: 
//  Returns: 

    public String getCustomerAppointmentService(int customerElement) {
        return this.customerAppointments.get(customerElement).getServiceRequested();
    }

//  Method: getCustomerAppointmentService
//  Purpose: 
//  Arguments: 
//  Returns: 

    public void setCustomerAppointmentService(int customerElement, String serviceRequested) {
        this.customerAppointments.get(customerElement).modifyAppointmentService(serviceRequested);
    }

}
