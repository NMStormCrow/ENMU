package project3_crow_thomas;

import java.util.*;
import java.time.format.*;
import java.time.LocalDateTime;

public class Garage {
    
// Instance variables    
    Scanner scan = new Scanner(System.in);
    private ArrayList<Customer> customers = new ArrayList<Customer>();
    private ArrayList<Expense> expenses = new ArrayList<Expense>();
    private ArrayList<JobHistory> jobhistories = new ArrayList<JobHistory>();
    private ArrayList<Manager> managers = new ArrayList<Manager>();
    private ArrayList<Mechanic> mechanics = new ArrayList<Mechanic>();
    private ArrayList<Revenue> revenues = new ArrayList<Revenue>();
    private ArrayList<ServiceDesk> servicedeskclerks = new ArrayList<ServiceDesk>();

//  Method: addCustomer()
//  Purpose: 
//  Arguments:
//  Returns: 

    public void addCustomer(String customerName, String customerAddress, String customerPhone, String customerEmail, LocalDateTime appointmentDate, String serviceRequested, String vehicleBrand, String vehicleModel, String vehicleYear, String vehicleMileage) {
        Customer newCustomer = new Customer(customerName, customerAddress, customerPhone, customerEmail);
        newCustomer.addCustomerAppointment(appointmentDate, serviceRequested);
        newCustomer.addCustomerVehicle(vehicleBrand, vehicleModel, vehicleYear, vehicleMileage);
        this.customers.add(newCustomer);
    }




//  Method: addMechanic()
//  Purpose: 
//  Arguments:
//  Returns: 

    public void addMechanic(String employeeName, double employeeWage, ArrayList<String> mechanicVehicleCertifications, double weeklyHours) {

        Mechanic newMechanic = new Mechanic(employeeName, employeeWage, mechanicVehicleCertifications, weeklyHours);
        this.mechanics.add(newMechanic);

    }

//  Method: addManager()
//  Purpose: 
//  Arguments:
//  Returns: 

    public void addManager(String employeeName, double employeeWage, ArrayList<String> employeesManaged, double weeklyHours) {

        Manager newManager = new Manager(employeeName, employeeWage, employeesManaged, weeklyHours);
        this.managers.add(newManager);

    }

//  Method: addServiceDesk()
//  Purpose: 
//  Arguments:
//  Returns: 

    public void addServiceDesk(String employeeName, double employeeWage, double weeklyHours) {

        ServiceDesk newServiceDesk = new ServiceDesk(employeeName, employeeWage, weeklyHours);
        this.servicedeskclerks.add(newServiceDesk);

    }

//  Method: addExpenses()
//  Purpose: 
//  Arguments:
//  Returns: 

    public void addExpenses(String expenseName, LocalDateTime expenseDate, Double expenseAmount) {

        Expense newExpense = new Expense(expenseName, expenseDate, expenseAmount);
        this.expenses.add(newExpense);

    }

//  Method: addExpenses()
//  Purpose: 
//  Arguments:
//  Returns: 

    public void addRevenue(String revenueName, LocalDateTime revenueDate, Double revenueAmount) {

        Revenue newRevenue = new Revenue(revenueName, revenueDate, revenueAmount);
        this.revenues.add(newRevenue);

    }

//  Method: addExpenses()
//  Purpose: 
//  Arguments:
//  Returns: 

    public void addJobHistory(LocalDateTime serviceDate, String serviceProvided, String serviceNotes) {

        JobHistory newJobHistory = new JobHistory(serviceDate, serviceProvided, serviceNotes);
        this.jobhistories.add(newJobHistory);

    }


//  Method: garageMenu()
//  Purpose: Top level menu
//  Arguments: None
//  Returns: None

    public void garageMenu() {

        String userChoice = "0";
        while (!(userChoice.toUpperCase().equals("Q"))) {
            System.out.println("Enter a selection");
            System.out.println("Enter 1 for customer menu.");
            System.out.println("Enter 2 for employee menu.");
            System.out.println("Enter 3 for job history menu.");
            System.out.println("Enter 4 for finance menu.");
            System.out.println("Enter Q to quit program.");
            userChoice = scan.nextLine();

//          Enter customer menu
            if (userChoice.equals("1")) {
                customerMenu();
            }
//          Enter employee menu
            if (userChoice.equals("2")) {
                employeeMenu();
            }
//          Enter job history menu
            if (userChoice.equals("4")) {
                //jobhistoryMenu();
            }
//          Enter employee menu
            if (userChoice.equals("4")) {
                financeMenu();
            }
//          Quit the program
            else if (userChoice.toUpperCase().equals("Q")) {  
                System.out.println("Exiting the customer menu");
            }
//          Any other entry
            else {  
                System.out.println("Invalid entry");
            }
        }
    }


//  Method: customerMenu()
//  Purpose: View and Modify customer records
//  Arguments: None
//  Returns: None


    private void customerMenu() {

        String userChoice = "0";
        Customer customer;
        String customerName;
        String customerAddress;
        String customerPhone;
        String customerEmail;
        int customerElement;

        while (!(userChoice.toUpperCase().equals("Q"))) {
            System.out.println("Enter a selection");
            System.out.println("Enter 1 for a list of customers.");
            System.out.println("Enter 2 to add a customer.");
            System.out.println("Enter 3 to modify a customer's personal information");
            System.out.println("Enter 4 to schedule an appointment.");
            System.out.println("Enter 5 to modify an appointment");
            System.out.println("Enter 6 to cancel an appointment");
            System.out.println("Enter 7 to list a customer's appointment");
            System.out.println("Enter 8 to list customer's vehicles");
            System.out.println("Enter 9 to add a vehicle");
            System.out.println("Enter 10 to modify a vehicle");
            System.out.println("Enter 11 to remove a vehicle");
            System.out.println("Enter Q exit customer menu.");
            userChoice = scan.nextLine();

//          List customer information          
            if (userChoice.equals("1")) {
                for (int i = 0; i < this.customers.size(); i++) {
                    customer = this.customers.get(i);
                    customer.showCustomerInfo();
                }
            }
//          Add a customer
            else if (userChoice.equals("2")) {
                System.out.println("Enter the name of the customer");
                customerName = scan.nextLine();
                System.out.println("Enter the address of the customer");
                customerAddress = scan.nextLine();
                System.out.println("Enter the phone of the customer");
                customerPhone = scan.nextLine();
                System.out.println("Enter the email address of the customer");
                customerEmail = scan.nextLine();
                customer = new Customer(customerName, customerAddress, customerPhone, customerEmail);
                this.customers.add(customer);
            }


//          Modify customer's personal info
            else if (userChoice.equals("3")) {  
                System.out.println("Enter the name of the customer");
                customerName = scan.nextLine();                    
                for (int i = 0; i < this.customers.size(); i++) {
                    if (customerName.equals(this.customers.get(i).getCustomerName())) {
                        System.out.println("The current name of the customer is: " + this.customers.get(i).getCustomerName());
                        System.out.println("Would you like to change it? Y or N");
                        userChoice = scan.nextLine();
                        if (userChoice.toUpperCase().equals("Y")) {
                            System.out.println("Please enter a new name:");
                            userChoice = scan.nextLine();
                            this.customers.get(i).modifyCustomerName(userChoice);
                        }
                        System.out.println("The current address of the customer is: " + this.customers.get(i).getCustomerAddress());
                        System.out.println("Would you like to change it? Y or N");
                        userChoice = scan.nextLine();
                        if (userChoice.toUpperCase().equals("Y")) {
                            System.out.println("Please enter a new address:");
                            userChoice = scan.nextLine();
                            this.customers.get(i).modifyCustomerAddress(userChoice);
                        }
                        System.out.println("The current phone number of the customer is: " + this.customers.get(i).getCustomerPhone());
                        System.out.println("Would you like to change it? Y or N");
                        userChoice = scan.nextLine();
                        if (userChoice.toUpperCase().equals("Y")) {
                            System.out.println("Please enter a new phone number:");
                            userChoice = scan.nextLine();
                            this.customers.get(i).modifyCustomerPhone(userChoice);
                        }
                        System.out.println("The current email address of the customer is: " + this.customers.get(i).getCustomerEmail());
                        System.out.println("Would you like to change it? Y or N");
                        userChoice = scan.nextLine();
                        if (userChoice.toUpperCase().equals("Y")) {
                            System.out.println("Please enter a new email address:");
                            userChoice = scan.nextLine();
                            this.customers.get(i).modifyCustomerEmail(userChoice);
                        }
                    }
                }
            }
//          Schedule a customer's appointment 
            else if (userChoice.equals("4")) {  
                System.out.println("Enter the name of the customer:");
                customerName = scan.nextLine();                    
                for (int i = 0; i < this.customers.size(); i++) {
                    if (customerName.equals(this.customers.get(i).getCustomerName())) {
                        try {
                            System.out.println("Date-time in format: MM-dd-yyyy HH:mm");
                            String date = scan.nextLine();
                            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-dd-yyyy HH:mm");
                            LocalDateTime appointmentDate = LocalDateTime.parse(date, formatter); 
                            System.out.println("Please enter the service requested");
                            String serviceRequested = scan.nextLine();
                            this.customers.get(i).addCustomerAppointment(appointmentDate, serviceRequested);
                        }
                        catch(Exception e) {
                            System.out.println("Invalid format entered. Press enter to continue:");
                            scan.nextLine();
                        }
                    }
                }
            }
//          Modify a customer's appointment
            else if (userChoice.equals("5")) {  

                System.out.println("Enter the name of the customer:");
                customerName = scan.nextLine(); 
                for (int i = 0; i < this.customers.size(); i++) {
                    if (customerName.equals(this.customers.get(i).getCustomerName())) {
                        customer = this.customers.get(i);
                        customer.showCustomerAppointments();
                        customerElement = i;
                        System.out.println("Enter which number you would like to modify:");
                        String appointmentElement = scan.nextLine();
                        System.out.println("The current time of the appointment is: " + this.customers.get(i).getCustomerAppointmentTime(Integer.parseInt(appointmentElement) - 1));
                        System.out.println("Would you like to change it? Y or N");
                        userChoice = scan.nextLine();
                        if (userChoice.toUpperCase().equals("Y")) {
                            try {
                                System.out.println("Please enter the appointment's date and time in format: MM-dd-yyyy HH:mm");
                                String date = scan.nextLine();
                                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-dd-yyyy HH:mm");
                                LocalDateTime appointmentDate = LocalDateTime.parse(date, formatter); 
                                this.customers.get(customerElement).modifyCustomerAppointmentTime(appointmentDate, (Integer.parseInt(appointmentElement) - 1));    
                            }
                            catch(Exception e) {
                                System.out.println("Invalid format entered. Press enter to continue:");
                                scan.nextLine();
                            }
                        }
                        System.out.println("The current service request of the appointment is: " + this.customers.get(i).getCustomerAppointmentService(Integer.parseInt(appointmentElement) - 1));
                        System.out.println("Would you like to change it? Y or N");
                        userChoice = scan.nextLine();
                        if (userChoice.toUpperCase().equals("Y")) {
                            System.out.println("Please enter the service requested");
                            String serviceRequested = scan.nextLine();
                            this.customers.get(customerElement).setCustomerAppointmentService(Integer.parseInt(appointmentElement) - 1, serviceRequested);
                        }
                    }
                }
            }

//          Cancel a customer's appointment
            else if (userChoice.equals("6")) {  
                System.out.println("Enter the name of the customer:");
                customerName = scan.nextLine();                    
                for (int i = 0; i < this.customers.size(); i++) {
                    if (customerName.equals(this.customers.get(i).getCustomerName())) {
                        customer = this.customers.get(i);
                        customer.showCustomerAppointments();
                        customerElement = i;
                        System.out.println("Enter which number you would like to remove:");
                        userChoice = scan.nextLine();
                        this.customers.get(customerElement).removeCustomerAppointment((Integer.parseInt(userChoice) - 1));
                    }
                }                
            }

//          List a customer's appointment
            else if (userChoice.equals("7")) {  
                System.out.println("Enter the name of the customer");
                customerName = scan.nextLine();                    
                for (int i = 0; i < this.customers.size(); i++) {
                    if (customerName.equals(this.customers.get(i).getCustomerName())) {
                        customer = this.customers.get(i);
                        customer.showCustomerAppointments();
                    }
                }
            }

//          List a customer's vehicles
            else if (userChoice.equals("8")) {
                System.out.println("Enter the name of the customer");
                customerName = scan.nextLine();                    
                for (int i = 0; i < this.customers.size(); i++) {
                    if (customerName.equals(this.customers.get(i).getCustomerName())) {
                        customer = this.customers.get(i);
                        customer.showCustomerVehicles();
                    }
                }
            }
            
//          Add a vehicle to a customer
            else if (userChoice.equals("9")) {  
                System.out.println("Enter the name of the customer:");
                customerName = scan.nextLine();                    
                for (int i = 0; i < this.customers.size(); i++) {
                    if (customerName.equals(this.customers.get(i).getCustomerName())) {
                        customerElement = i;
                        customer = this.customers.get(customerElement);
                        System.out.println("Enter the vehicle brand:");
                        String vehicleBrand = scan.nextLine();
                        System.out.println("Enter the vehicle model:");
                        String vehicleModel = scan.nextLine();
                        System.out.println("Enter the vehicle year:");
                        String vehicleYear = scan.nextLine();
                        System.out.println("Enter the vehicle mileage:");
                        String vehicleMileage = scan.nextLine();
                        this.customers.get(customerElement).addCustomerVehicle(vehicleBrand, vehicleModel, vehicleYear, vehicleMileage);
                    }
                }
            }

//          Modify a customer's vehicle
            else if (userChoice.equals("10")) {  
            
                System.out.println("Enter the name of the customer:");
                customerName = scan.nextLine(); 
                for (int i = 0; i < this.customers.size(); i++) {
                    if (customerName.equals(this.customers.get(i).getCustomerName())) {
                        customer = this.customers.get(i);
                        customer.showCustomerVehicles();
                        customerElement = i;
                        System.out.println("Enter which number you would like to modify:");
                        String appointmentElement = scan.nextLine();
                        System.out.println("The current brand of the vehicle is: " + this.customers.get(i).getCustomerVehicleBrand(Integer.parseInt(appointmentElement) - 1));
                        System.out.println("Would you like to change it? Y or N");
                        userChoice = scan.nextLine();
                        if (userChoice.toUpperCase().equals("Y")) {
                            System.out.println("Please enter the vehicle model");
                            String brandRequested = scan.nextLine();
                            this.customers.get(customerElement).setCustomerVehicleBrand(Integer.parseInt(appointmentElement) - 1, brandRequested);
                        }
                        System.out.println("The current model of the vehicle is: " + this.customers.get(i).getCustomerVehicleModel(Integer.parseInt(appointmentElement) - 1));
                        System.out.println("Would you like to change it? Y or N");
                        userChoice = scan.nextLine();
                        if (userChoice.toUpperCase().equals("Y")) {
                            System.out.println("Please enter the vehicle model");
                            String modelRequested = scan.nextLine();
                            this.customers.get(customerElement).setCustomerVehicleModel(Integer.parseInt(appointmentElement) - 1, modelRequested);
                        }
                        System.out.println("The current year of the vehicle is: " + this.customers.get(i).getCustomerVehicleYear(Integer.parseInt(appointmentElement) - 1));
                        System.out.println("Would you like to change it? Y or N");
                        userChoice = scan.nextLine();
                        if (userChoice.toUpperCase().equals("Y")) {
                            System.out.println("Please enter the vehicle year");
                            String yearRequested = scan.nextLine();
                            this.customers.get(customerElement).setCustomerVehicleYear(Integer.parseInt(appointmentElement) - 1, yearRequested);
                        }
                        System.out.println("The current mileage of the vehicle is: " + this.customers.get(i).getCustomerVehicleMileage(Integer.parseInt(appointmentElement) - 1));
                        System.out.println("Would you like to change it? Y or N");
                        userChoice = scan.nextLine();
                        if (userChoice.toUpperCase().equals("Y")) {
                            System.out.println("Please enter the vehicle mileage");
                            String mileageRequested = scan.nextLine();
                            this.customers.get(customerElement).setCustomerVehicleMileage(Integer.parseInt(appointmentElement) - 1, mileageRequested);
                        }
                    }
                }
            }


//          Remove a customer's vehicle
            else if (userChoice.equals("11")) {  
                System.out.println("Enter the name of the customer:");
                customerName = scan.nextLine();                    
                for (int i = 0; i < this.customers.size(); i++) {
                    if (customerName.equals(this.customers.get(i).getCustomerName())) {
                        customerElement = i;
                        customer = this.customers.get(customerElement);
                        customer.showCustomerVehicles();
                        System.out.println("Select the number of the vehicle you want to delete. Choose Q to cancel.");
                        userChoice = scan.nextLine();
                        try {
                            if (!(userChoice.toUpperCase().equals("Q"))) {
                            this.customers.get(customerElement).removeCustomerVehicle((Integer.parseInt(userChoice)) - 1);
                            }
                        }
                        catch (Exception e) {
                            System.out.println("Invalid entry");
                            userChoice = "";
                        }
                    }
                }                
            }
            

//          Quit the program
            else if (userChoice.toUpperCase().equals("Q")) {  
                System.out.println("Exiting the customer menu");
            }

//          Any other entry
            else {  
                System.out.println("Invalid entry");
            }
        }
    }

//  Method: employeeMenu()
//  Purpose: View and Modify employee records
//  Arguments: None
//  Returns: None


    private void employeeMenu() {

        String userChoice = "0";
        while (!(userChoice.toUpperCase().equals("Q"))) {
            System.out.println("Enter a selection");
            System.out.println("Enter 1 to view mechanic menu");
            System.out.println("Enter 2 to view manager menu");
            System.out.println("Enter 3 to view service desk menu");
            System.out.println("Enter Q to quit employee menu.");
            userChoice = scan.nextLine();

//          View mechanic menu
            if (userChoice.equals("1")) {
                mechanicMenu();
            }

//          View manager menu
            else if (userChoice.equals("2")) {
                managerMenu();
            }

//          View service desk menu
            else if (userChoice.equals("3")) {
                serviceDeskMenu();      
            }

//          Quit the program
            else if (userChoice.toUpperCase().equals("Q")) {  
                System.out.println("Exiting the employee menu");
            }

//          Any other entry
            else {  
                System.out.println("Invalid entry");
            }
            
        }

    }


//  Method: mechanicMenu()
//  Purpose: View and Modify customer records
//  Arguments: None
//  Returns: None


    private void mechanicMenu() {

        String userChoice = "0";
        Mechanic mechanic;
        String mechanicName;
        Double mechanicWage;
        Double mechanicWeeklyHours;
        ArrayList<String> certifications = new ArrayList<String>();

        while (!(userChoice.toUpperCase().equals("Q"))) {
            System.out.println("Enter a selection");
            System.out.println("Enter 1 to view all mechanics.");
            System.out.println("Enter 2 to add a mechanic.");
            System.out.println("Enter 3 to modify mechanic entry.");
            System.out.println("Enter 4 to remove mechanic entry");
            System.out.println("Enter 5 to view mechanic's certifications");
            System.out.println("Enter 6 to add a mechanic certification.");
            System.out.println("Enter 7 to remove a mechanic certification");
            System.out.println("Enter Q to quit mechanic menu.");
            userChoice = scan.nextLine();

//          List mechanic information          
            if (userChoice.equals("1")) {
                for (int i = 0; i < this.mechanics.size(); i++) {
                    mechanic = this.mechanics.get(i);
                    System.out.println("Name\t\t|\tWage\t|\tWeekly Hours");
                    System.out.println(mechanic.showMechanicInfo());
                }
            }

//          Add a mechanic
            else if (userChoice.equals("2")) {
                System.out.println("Enter the name of the mechanic");
                mechanicName = scan.nextLine();
                System.out.println("Enter the wage of the mechanic");
                mechanicWage = (Double.parseDouble(scan.nextLine()));
                System.out.println("Enter the weekly hours of the mechanic");
                mechanicWeeklyHours = (Double.parseDouble(scan.nextLine()));
                userChoice = "";
                while (!(userChoice.toUpperCase().equals("Q"))) {
                    System.out.println("Enter a certification for the mechanic. Type Q to quit:");
                    userChoice = scan.nextLine();
                    if (userChoice.toUpperCase().equals("Q")) {
                        certifications.add(userChoice);
                    }
                }
                mechanic = new Mechanic(mechanicName, mechanicWage, certifications, mechanicWeeklyHours);
                this.mechanics.add(mechanic);
            }

//          Modify a mechanics entry  
            else if (userChoice.equals("3")) {  
                System.out.println("Enter the name of the mechanic");
                mechanicName = scan.nextLine();                    
                for (int i = 0; i < this.mechanics.size(); i++) {
                    if (mechanicName.equals(this.mechanics.get(i).getMechanicName())) {
                        System.out.println("The current name of the mechanic is: " + this.mechanics.get(i).getMechanicName());
                        System.out.println("Would you like to change it? Y or N");
                        userChoice = scan.nextLine();
                        if (userChoice.toUpperCase().equals("Y")) {
                            System.out.println("Please enter a new name:");
                            mechanicName = scan.nextLine();
                            this.mechanics.get(i).setMechanicName(mechanicName);
                        }
                        System.out.println("The current wage of the mechanic is: " + this.mechanics.get(i).getMechanicWage());
                        System.out.println("Would you like to change it? Y or N");
                        userChoice = scan.nextLine();
                        if (userChoice.toUpperCase().equals("Y")) {
                            System.out.println("Please enter a new wage:");
                            mechanicWage = (Double.parseDouble(scan.nextLine()));
                            this.mechanics.get(i).setMechanicWage(mechanicWage);
                        }
                        System.out.println("The current weekly hours for the mechanic is: " + this.mechanics.get(i).getMechanicWeeklyHours());
                        System.out.println("Would you like to change it? Y or N");
                        userChoice = scan.nextLine();
                        if (userChoice.toUpperCase().equals("Y")) {
                            System.out.println("Please enter new weekly hours:");
                            mechanicWeeklyHours = (Double.parseDouble(scan.nextLine()));
                            this.mechanics.get(i).setMechanicWeeklyHours(mechanicWeeklyHours);
                        }
                    }
                }
            }

//          Remove a mechanics entry  
            else if (userChoice.equals("4")) {  
                System.out.println("Enter the name of the mechanic");
                mechanicName = scan.nextLine();                    
                for (int i = 0; i < this.mechanics.size(); i++) {
                    if (mechanicName.equals(this.mechanics.get(i).getMechanicName())) {
                        this.mechanics.remove(i);
                    }
                }
            }

//          View a mechanics certifications
            else if (userChoice.equals("5")) {
                System.out.println("Enter the name of the mechanic");
                mechanicName = scan.nextLine();                    
                for (int i = 0; i < this.mechanics.size(); i++) {
                    if (mechanicName.equals(this.mechanics.get(i).getMechanicName())) {
                        certifications = this.mechanics.get(i).getMechanicVehicleCertifications();
                        System.out.println("The mechanic " + this.mechanics.get(i).getMechanicName() + "has the following certificates:");
                        for (int j = 0; j < certifications.size(); j++) {
                            System.out.println(certifications.get(j));
                        }
                    System.out.println();
                    }
                }
            }

//          Add a mechanics certifications
            else if (userChoice.equals("6")) {
                System.out.println("Enter the name of the mechanic");
                mechanicName = scan.nextLine();                    
                for (int i = 0; i < this.mechanics.size(); i++) {
                    if (mechanicName.equals(this.mechanics.get(i).getMechanicName())) {
                        while (!(userChoice.toUpperCase().equals("Q"))) {
                            System.out.println("Enter a certification for the mechanic. Type Q to quit:");
                            userChoice = scan.nextLine();
                            if (!(userChoice.toUpperCase().equals("Q"))) {
                                this.mechanics.get(i).addMechanicVehicleCertification(userChoice);
                            }
                            else {
                                userChoice = "";
                            
                            }
                        }
                    }
                }
            }

//          Remove a mechanics certification
            else if (userChoice.equals("7")) {
                System.out.println("Enter the name of the mechanic");
                mechanicName = scan.nextLine();                    
                for (int i = 0; i < this.mechanics.size(); i++) {
                    if (mechanicName.equals(this.mechanics.get(i).getMechanicName())) {
                        certifications = this.mechanics.get(i).getMechanicVehicleCertifications();
                        System.out.println("The mechanic " + this.mechanics.get(i).getMechanicName() + "has the following certificates:");
                        for (int j = 0; j < certifications.size(); j++) {
                            System.out.println(certifications.get(j));
                        }
                        System.out.println("Please enter the certificate to remove:");
                        String removeCertification = scan.nextLine();
                        for (int j = 0; j < certifications.size(); j++) {
                            if (removeCertification.equals(certifications.get(j))) {
                                this.mechanics.get(i).removeMechanicVehicleCertification(j);
                            }
                        }
                    }
                }
            }

            else if (userChoice.toUpperCase().equals("Q")) {
                System.out.println("Exiting mechanic menu");
            }

            else {
                System.out.println("Invalid Entry");
            }


        }       
    }

//  Method: managerMenu()
//  Purpose: View and Modify manager records
//  Arguments: None
//  Returns: None


    private void managerMenu() {

        String userChoice = "0";
        Manager manager;
        String managerName;
        Double managerWage;
        Double managerWeeklyHours;
        ArrayList<String> managedEmployees = new ArrayList<String>();


        while (!(userChoice.toUpperCase().equals("Q"))) {
            System.out.println("Enter a selection");
            System.out.println("Enter 1 to view all managers");
            System.out.println("Enter 2 to add a manager");
            System.out.println("Enter 3 to modify manager entry.");
            System.out.println("Enter 4 to remove manager entry");
            System.out.println("Enter 5 to view all employees managed.");
            System.out.println("Enter 6 to add a managed employee.");
            System.out.println("Enter 7 to remove a managed employee");
            System.out.println("Enter Q to quit mechanic menu.");
            userChoice = scan.nextLine();

//          List manager information          
            if (userChoice.equals("1")) {
                for (int i = 0; i < this.managers.size(); i++) {
                    manager = this.managers.get(i);
                    System.out.println("Name\t\t|\tWage\t|\tWeekly Hours");
                    System.out.println(manager.showManagerInfo());
                }
            }

//          Add a manager
            else if (userChoice.equals("2")) {
                System.out.println("Enter the name of the manager");
                managerName = scan.nextLine();
                System.out.println("Enter the wage of the manager");
                managerWage = (Double.parseDouble(scan.nextLine()));
                System.out.println("Enter the weekly hours of the manager");
                managerWeeklyHours = (Double.parseDouble(scan.nextLine()));
                userChoice = "";
                while (!(userChoice.toUpperCase().equals("Q"))) {
                    System.out.println("Enter a managed employee for the manager. Type Q to quit:");
                    userChoice = scan.nextLine();
                    if (userChoice.toUpperCase().equals("Q")) {
                        managedEmployees.add(userChoice);
                    }
                }
                manager = new Manager(managerName, managerWage, managedEmployees, managerWeeklyHours);
                this.managers.add(manager);
            }

//          Modify a manager entry  
            else if (userChoice.equals("3")) {  
                System.out.println("Enter the name of the manager");
                managerName = scan.nextLine();                    
                for (int i = 0; i < this.managers.size(); i++) {
                    if (managerName.equals(this.managers.get(i).getManagerName())) {
                        System.out.println("The current name of the manager is: " + this.managers.get(i).getManagerName());
                        System.out.println("Would you like to change it? Y or N");
                        userChoice = scan.nextLine();
                        if (userChoice.toUpperCase().equals("Y")) {
                            System.out.println("Please enter a new name:");
                            managerName = scan.nextLine();
                            this.managers.get(i).setManagerName(managerName);
                        }
                        System.out.println("The current wage of the manager is: " + this.managers.get(i).getManagerWage());
                        System.out.println("Would you like to change it? Y or N");
                        userChoice = scan.nextLine();
                        if (userChoice.toUpperCase().equals("Y")) {
                            System.out.println("Please enter a new wage:");
                            managerWage = (Double.parseDouble(scan.nextLine()));
                            this.managers.get(i).setManagerWage(managerWage);
                        }
                        System.out.println("The current weekly hours for the manager is: " + this.managers.get(i).getManagerWeeklyHours());
                        System.out.println("Would you like to change it? Y or N");
                        userChoice = scan.nextLine();
                        if (userChoice.toUpperCase().equals("Y")) {
                            System.out.println("Please enter new weekly hours:");
                            managerWeeklyHours = (Double.parseDouble(scan.nextLine()));
                            this.managers.get(i).setManagerWeeklyHours(managerWeeklyHours);
                        }
                    }
                }
            }

//          Remove a managers entry  
            else if (userChoice.equals("4")) {  
                System.out.println("Enter the name of the manager");
                managerName = scan.nextLine();                    
                for (int i = 0; i < this.mechanics.size(); i++) {
                    if (managerName.equals(this.managers.get(i).getManagerName())) {
                        this.managers.remove(i);
                    }
                }
            }

//          View a managers managed employees
            else if (userChoice.equals("5")) {
                System.out.println("Enter the name of the manager");
                managerName = scan.nextLine();                    
                for (int i = 0; i < this.managers.size(); i++) {
                    if (managerName.equals(this.managers.get(i).getManagerName())) {
                        managedEmployees = this.managers.get(i).getManagedEmployees();
                        System.out.println("The manager " + this.managers.get(i).getManagerName() + "has the following employees:");
                        for (int j = 0; j < managedEmployees.size(); j++) {
                            System.out.println(managedEmployees.get(j));
                        }
                    System.out.println();
                    }
                }
            }

//          Add a managed employee
            else if (userChoice.equals("6")) {
                System.out.println("Enter the name of the manager");
                managerName = scan.nextLine();                    
                for (int i = 0; i < this.managers.size(); i++) {
                    if (managerName.equals(this.managers.get(i).getManagerName())) {
                        while (!(userChoice.toUpperCase().equals("Q"))) {
                            System.out.println("Enter a managed employee. Type Q to quit:");
                            userChoice = scan.nextLine();
                            if (!(userChoice.toUpperCase().equals("Q"))) {
                                this.managers.get(i).addManagedEmloyee(userChoice);
                            }
                            else {
                                userChoice = "";
                            
                            }
                        }
                    }
                }
            }

//          Remove a managed employee
            else if (userChoice.equals("7")) {
                System.out.println("Enter the name of the manager");
                managerName = scan.nextLine();                    
                for (int i = 0; i < this.managers.size(); i++) {
                    if (managerName.equals(this.managers.get(i).getManagerName())) {
                        managedEmployees = this.managers.get(i).getManagedEmployees();
                        System.out.println("The mechanic " + this.managers.get(i).getManagerName() + "has the following managed employees:");
                        for (int j = 0; j < managedEmployees.size(); j++) {
                            System.out.println(managedEmployees.get(j));
                        }
                        System.out.println("Please enter the managed employees to remove:");
                        String removeManagedEmployees = scan.nextLine();
                        for (int j = 0; j < managedEmployees.size(); j++) {
                            if (removeManagedEmployees.equals(managedEmployees.get(j))) {
                                this.managers.get(i).removeManagedEmployee(j);
                            }
                        }
                    }
                }
            }

            else if (userChoice.toUpperCase().equals("Q")) {
                System.out.println("Exiting managers menu");
            }

            else {
                System.out.println("Invalid Entry");
            }




        }
    }
//  Method: mechanicMenu()
//  Purpose: View and Modify customer records
//  Arguments: None
//  Returns: None


    private void serviceDeskMenu() {

        String userChoice = "0";
        ServiceDesk serviceDeskEmployee;
        String serviceDeskEmployeeName;
        Double serviceDeskEmployeeWage;
        Double serviceDeskEmployeeWeeklyHours;
        

        while (!(userChoice.toUpperCase().equals("Q"))) {
            System.out.println("Enter a selection");
            System.out.println("Enter 1 to view all service desk clerk.");
            System.out.println("Enter 2 to add a service desk clerk.");
            System.out.println("Enter 3 to modify a service desk clerk.");
            System.out.println("Enter 4 to remove a service desk clerk");
            System.out.println("Enter Q to quit mechanic menu.");
            userChoice = scan.nextLine();

            //  List all service desk clerk          
            if (userChoice.equals("1")) {
                for (int i = 0; i < this.servicedeskclerks.size(); i++) {
                    serviceDeskEmployee = this.servicedeskclerks.get(i);
                    System.out.println("Name\t\t|\tWage\t|\tWeekly Hours");
                    System.out.println(serviceDeskEmployee.showServiceDeskInfo());
                }
            }

//          Add a service desk clerk
            else if (userChoice.equals("2")) {
                System.out.println("Enter the name of the service desk clerk");
                serviceDeskEmployeeName = scan.nextLine();
                System.out.println("Enter the wage of the service desk clerk");
                serviceDeskEmployeeWage = (Double.parseDouble(scan.nextLine()));
                System.out.println("Enter the weekly hours of the service desk clerk");
                serviceDeskEmployeeWeeklyHours = (Double.parseDouble(scan.nextLine()));
                serviceDeskEmployee = new ServiceDesk(serviceDeskEmployeeName, serviceDeskEmployeeWage, serviceDeskEmployeeWeeklyHours);
                this.servicedeskclerks.add(serviceDeskEmployee);
            }

//          Modify a service desk clerk  entry  
            else if (userChoice.equals("3")) {  
                System.out.println("Enter the name of the service desk clerk");
                serviceDeskEmployeeName= scan.nextLine();                    
                for (int i = 0; i < this.servicedeskclerks.size(); i++) {
                    if (serviceDeskEmployeeName.equals(this.servicedeskclerks.get(i).getServiceDeskName())) {
                        System.out.println("The current name of the service desk clerk is: " + this.servicedeskclerks.get(i).getServiceDeskName());
                        System.out.println("Would you like to change it? Y or N");
                        userChoice = scan.nextLine();
                        if (userChoice.toUpperCase().equals("Y")) {
                            System.out.println("Please enter a new name:");
                            serviceDeskEmployeeName = scan.nextLine();
                            this.servicedeskclerks.get(i).setServiceDeskName(serviceDeskEmployeeName);
                        }
                        System.out.println("The current wage of the service desk clerk is: " + this.servicedeskclerks.get(i).getServiceDeskWage());
                        System.out.println("Would you like to change it? Y or N");
                        userChoice = scan.nextLine();
                        if (userChoice.toUpperCase().equals("Y")) {
                            System.out.println("Please enter a new wage:");
                            serviceDeskEmployeeWage = (Double.parseDouble(scan.nextLine()));
                            this.servicedeskclerks.get(i).setServiceDeskWage(serviceDeskEmployeeWage);
                        }
                        System.out.println("The current weekly hours for the service desk clerk is: " + this.servicedeskclerks.get(i).getServiceDeskWeeklyHours());
                        System.out.println("Would you like to change it? Y or N");
                        userChoice = scan.nextLine();
                        if (userChoice.toUpperCase().equals("Y")) {
                            System.out.println("Please enter new weekly hours:");
                            serviceDeskEmployeeWeeklyHours = (Double.parseDouble(scan.nextLine()));
                            this.servicedeskclerks.get(i).setServiceDeskWeeklyHours(serviceDeskEmployeeWeeklyHours);
                        }
                    }
                }
            }

//          Remove a managers entry  
            else if (userChoice.equals("4")) {  
                System.out.println("Enter the name of the service desk clerk");
                serviceDeskEmployeeName = scan.nextLine();                    
                for (int i = 0; i < this.mechanics.size(); i++) {
                    if (serviceDeskEmployeeName.equals(this.servicedeskclerks.get(i).getServiceDeskName())) {
                        this.servicedeskclerks.remove(i);
                    }
                }
            }


        }
    }

//  Method: financeMenu()
//  Purpose: View financeMenu
//  Arguments: None
//  Returns: None

    public void financeMenu() {
        String userChoice = "0";
        while (!(userChoice.toUpperCase().equals("Q"))) {
            System.out.println("Enter a selection");
            System.out.println("Enter 1 to view expense menu");
            System.out.println("Enter 2 to view revenue menu");
            System.out.println("Enter Q to quit employee menu.");
            userChoice = scan.nextLine();

//          View expense menu
            if (userChoice.equals("1")) {
                expenseMenu();
            }

//          View expense menu
            else if (userChoice.equals("2")) {
                revenueMenu();
            }

//          Quit the program
            else if (userChoice.toUpperCase().equals("Q")) {  
                System.out.println("Exiting the employee menu");
            }

//          Any other entry
            else {  
                System.out.println("Invalid entry");
            }
            
        }
    }

//  Method: expenseMenu()
//  Purpose: View expenseMenu
//  Arguments: None
//  Returns: None

    public void expenseMenu() {
        
        String userChoice = "";
        Expense expense;
        String expenseName;
        LocalDateTime expenseDate;
        Double expenseAmount;

        while (!(userChoice.toUpperCase().equals("Q"))) {
            System.out.println("Enter a selection");
            System.out.println("Enter 1 to view all expenses");
            System.out.println("Enter 2 to add an expense");
            System.out.println("Enter 3 to modify an expense");
            System.out.println("Enter 4 to remove an expense");
            System.out.println("Enter Q to quit mechanic menu.");
            userChoice = scan.nextLine();

//  List all expenses   

            if (userChoice.equals("1")) {
            for (int i = 0; i < this.expenses.size(); i++) {
                expense = this.expenses.get(i);
                System.out.println("Name\t\t|\tDate\t|\tAmount");
                System.out.println(expense.showExpenseInfo());
            }
        }

//  Add an expense
            else if (userChoice.equals("2")) {
                System.out.println("Enter the name of the expense");
                expenseName = scan.nextLine();
                System.out.println("Enter the date of the expense");
                try {
                    System.out.println("Enter expense date in format: MM-dd-yyyy HH:mm");
                    String date = scan.nextLine();
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-dd-yyyy HH:mm");
                    expenseDate = LocalDateTime.parse(date, formatter); 
                    System.out.println("Enter the amount of the expense");
                    expenseAmount = (Double.parseDouble(scan.nextLine()));
                    expense = new Expense(expenseName, expenseDate, expenseAmount);
                    this.expenses.add(expense);
                }
                catch(Exception e) {
                    System.out.println("Invalid format entered. Press enter to continue:");
                    scan.nextLine();
                }
            }
        

//      Modify an expense  
            else if (userChoice.equals("3")) {  
                System.out.println("Enter the name of the expense");
                expenseName = scan.nextLine();                    
                for (int i = 0; i < this.servicedeskclerks.size(); i++) {
                    if (expenseName.equals(this.expenses.get(i).getExpenseName())) {
                        System.out.println("The current name of the expense is: " + this.expenses.get(i).getExpenseName());
                        System.out.println("Would you like to change it? Y or N");
                        userChoice = scan.nextLine();
                        if (userChoice.toUpperCase().equals("Y")) {
                            System.out.println("Please enter a new name:");
                            expenseName = scan.nextLine();
                            this.expenses.get(i).setExpenseName(expenseName);
                        }
                        System.out.println("The current date of the expense is: " + this.expenses.get(i).getExpenseDate());
                        System.out.println("Would you like to change it? Y or N");
                        userChoice = scan.nextLine();
                        if (userChoice.toUpperCase().equals("Y")) {
                            System.out.println("Please enter a new date:");
                            try {
                                System.out.println("Enter expense date in format: MM-dd-yyyy HH:mm");
                                String date = scan.nextLine();
                                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-dd-yyyy HH:mm");
                                expenseDate = LocalDateTime.parse(date, formatter); 
                                this.expenses.get(i).setExpenseDate(expenseDate);
                            }
                            catch(Exception e) {
                                System.out.println("Invalid format entered. Press enter to continue:");
                                scan.nextLine();
                            }
                            
                        }
                        System.out.println("The current amount for the expense is: " + this.expenses.get(i).getExpenseAmount());
                        System.out.println("Would you like to change it? Y or N");
                        userChoice = scan.nextLine();
                        if (userChoice.toUpperCase().equals("Y")) {
                            System.out.println("Please enter the new amount");
                            expenseAmount = (Double.parseDouble(scan.nextLine()));
                            this.expenses.get(i).setExpenseAmount(expenseAmount);
                        }
                    }
                }
            }

//      Remove an expense entry  
            else if (userChoice.equals("4")) {  
                System.out.println("Enter the name of the expense");
                expenseName = scan.nextLine();                    
                for (int i = 0; i < this.expenses.size(); i++) {
                    if (expenseName.equals(this.expenses.get(i).getExpenseName())) {
                        this.expenses.remove(i);
                    }
                }
            }
        }
    }

//  Method: revenueMenu()
//  Purpose: View revenueMenu
//  Arguments: None
//  Returns: None

public void revenueMenu() {
        
    String userChoice = "";
    Revenue revenue;
    String revenueName;
    LocalDateTime revenueDate;
    Double revenueAmount;

    while (!(userChoice.toUpperCase().equals("Q"))) {
        System.out.println("Enter a selection");
        System.out.println("Enter 1 to view all revenues");
        System.out.println("Enter 2 to add an revenue");
        System.out.println("Enter 3 to modify an revenue");
        System.out.println("Enter 4 to remove an revenue");
        System.out.println("Enter Q to quit mechanic menu.");
        userChoice = scan.nextLine();

//  List all revenues   

        if (userChoice.equals("1")) {
            for (int i = 0; i < this.revenues.size(); i++) {
                revenue = this.revenues.get(i);
                System.out.println("Name\t\t|\tDate\t|\tAmount");
                System.out.println(revenue.showrevenueInfo());
            }
        }

//  Add a revenue
        else if (userChoice.equals("2")) {
            System.out.println("Enter the name of the revenue");
            revenueName = scan.nextLine();
            System.out.println("Enter the date of the revenue");
            try {
                System.out.println("Enter revenue date in format: MM-dd-yyyy HH:mm");
                String date = scan.nextLine();
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-dd-yyyy HH:mm");
                revenueDate = LocalDateTime.parse(date, formatter); 
                System.out.println("Enter the amount of the revenue");
                revenueAmount = (Double.parseDouble(scan.nextLine()));
                revenue = new Revenue(revenueName, revenueDate, revenueAmount);
                this.revenues.add(revenue);
            }
            catch(Exception e) {
                System.out.println("Invalid format entered. Press enter to continue:");
                scan.nextLine();
            }

        }

//      Modify an revenue  
        else if (userChoice.equals("3")) {  
            System.out.println("Enter the name of the revenue");
            revenueName = scan.nextLine();                    
            for (int i = 0; i < this.servicedeskclerks.size(); i++) {
                if (revenueName.equals(this.revenues.get(i).getrevenueName())) {
                    System.out.println("The current name of the revenue is: " + this.revenues.get(i).getrevenueName());
                    System.out.println("Would you like to change it? Y or N");
                    userChoice = scan.nextLine();
                    if (userChoice.toUpperCase().equals("Y")) {
                        System.out.println("Please enter a new name:");
                        revenueName = scan.nextLine();
                        this.revenues.get(i).setrevenueName(revenueName);
                    }
                    System.out.println("The current date of the revenue is: " + this.revenues.get(i).getrevenueDate());
                    System.out.println("Would you like to change it? Y or N");
                    userChoice = scan.nextLine();
                    if (userChoice.toUpperCase().equals("Y")) {
                        System.out.println("Please enter a new date:");
                        try {
                            System.out.println("Enter revenue date in format: MM-dd-yyyy HH:mm");
                            String date = scan.nextLine();
                            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-dd-yyyy HH:mm");
                            revenueDate = LocalDateTime.parse(date, formatter); 
                            this.revenues.get(i).setrevenueDate(revenueDate);
                        }
                        catch(Exception e) {
                            System.out.println("Invalid format entered. Press enter to continue:");
                            scan.nextLine();
                        }
                    }
                    System.out.println("The current amount for the revenue is: " + this.revenues.get(i).getrevenueAmount());
                    System.out.println("Would you like to change it? Y or N");
                    userChoice = scan.nextLine();
                    if (userChoice.toUpperCase().equals("Y")) {
                        System.out.println("Please enter the new amount");
                        revenueAmount = (Double.parseDouble(scan.nextLine()));
                        this.revenues.get(i).setrevenueAmount(revenueAmount);
                    }
                }
            }
        }

//          Remove an revenue entry  
        else if (userChoice.equals("4")) {  
            System.out.println("Enter the name of the revenue");
            revenueName = scan.nextLine();                    
            for (int i = 0; i < this.revenues.size(); i++) {
                if (revenueName.equals(this.revenues.get(i).getrevenueName())) {
                    this.revenues.remove(i);
                }
            }
        }
    }
}
}
