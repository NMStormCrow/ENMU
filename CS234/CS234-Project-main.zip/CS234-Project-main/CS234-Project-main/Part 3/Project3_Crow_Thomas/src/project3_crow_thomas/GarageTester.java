package project3_crow_thomas;

//import java.time.format.*;
import java.time.LocalDateTime;
import java.util.*;

public class GarageTester {
    
    public static void main(String args[]) {
        
//  Declare instance variables
        Garage testgarage = new Garage();
        ArrayList<String> certifications = new ArrayList<String>();
        ArrayList<String> managedEmployees = new ArrayList<String>();

// Creating an object of DateTimeFormatter class
        
        LocalDateTime appointmentDate;
        appointmentDate = LocalDateTime.of(2022, 4, 28, 14, 30);
        testgarage.addCustomer("John Smit", "45 Main St. Smallville, KS", "765-734-2352", "jsmit@luthorcorp.com", appointmentDate ,"Oil Change", "Ford", "F-150", "2005",  "145321");
        appointmentDate = LocalDateTime.of(2022, 5, 15, 9, 30);
        testgarage.addCustomer("Ryan Webber", "234 3rd St. Smallville, KS", "765-734-6543", "rwebber@luthorcorp.com", appointmentDate, "New tires", "Dodge", "Ram", "2014", "78325");
        certifications.add("Ford");
        certifications.add("Chevy");
        certifications.add("Dodge");
        testgarage.addMechanic("Mike York", 25, certifications, 40.0);
        managedEmployees.add("John Smit");
        managedEmployees.add("Ryan Webber");
        testgarage.addManager("Kelly Chavez", 30, managedEmployees, 40.0);
        testgarage.addServiceDesk("Cathy Black", 15, 30);

        testgarage.garageMenu();
    }
 }
