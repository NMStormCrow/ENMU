package project3_crow_thomas;

public class ServiceDesk extends Employee {
    
//  Default constructor
   
    public ServiceDesk (String employeeName, double employeeWage, double weeklyHours) {
        setEmployeeName(employeeName);
        setEmployeeWage(employeeWage);
        setWeeklyHours(weeklyHours);
    }

//  Method: showServiceDeskInfo()
//  Purpose: 
//  Arguments: 
//  Returns: 

    public String showServiceDeskInfo() {
        return (this.employeeName + "\t|\t" + this.employeeWage + "\t|\t" + this.weeklyHours);
    }

//  Method: getServiceDeskName()
//  Purpose:
//  Arguments
//  Returns: 

    public String getServiceDeskName() {
        return this.employeeName;
    }

//  Method: getServiceDeskWage()
//  Purpose:
//  Arguments
//  Returns: 

    public double getServiceDeskWage() {
        return this.employeeWage;
    }

//  Method: getServiceDeskWeeklyHours()
//  Purpose:
//  Arguments
//  Returns: 

    public double getServiceDeskWeeklyHours() {
        return this.weeklyHours;
    }

//  Method: setServiceDeskName()
//  Purpose:
//  Arguments
//  Returns: 

    public void setServiceDeskName(String ServiceDeskName) {
        this.employeeName = ServiceDeskName;
    }

//  Method: setServiceDeskWage
//  Purpose:
//  Arguments
//  Returns: 

    public void setServiceDeskWage(double ServiceDeskWage) {
        this.weeklyHours = ServiceDeskWage;
    }

//  Method: setServiceDeskWeeklyhours()
//  Purpose:
//  Arguments
//  Returns: 

    public void setServiceDeskWeeklyHours(Double ServiceDeskWeeklyHours) {
        this.weeklyHours = ServiceDeskWeeklyHours;
    }

}