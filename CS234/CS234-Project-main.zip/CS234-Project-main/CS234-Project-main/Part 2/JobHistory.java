import java.time.*;

public class JobHistory {

//  Declare instance variables
    private LocalDateTime serviceDate;
    private String serviceProvided;
    private String serviceNotes;

//  Default constructor

    public JobHistory(LocalDateTime serviceDate, String serviceProvided, String serviceNotes) {

        this.serviceDate = serviceDate;
        this.serviceProvided = serviceProvided;
        this.serviceNotes = serviceNotes;

    }

//  Method: showJobHistoryInfo()
//  Purpose: 
//  Arguments: 
//  Returns: 

    public String showJobHistoryInfo() {
    return (this.serviceDate + "\t|\t" + this.serviceProvided + "\t|\t" + this.serviceNotes);
    }


//  Method: getJobHistoryDate
//  Purpose:
//  Arguments:
//  Returns: 

    public LocalDateTime getJobHistoryDate() {
        return this.serviceDate;
    }


//  Method: getServiceProvided
//  Purpose:
//  Arguments:
//  Returns: 

    public String getServiceProvided() {
        return this.serviceProvided;
    }

//  Method: getServiceNotes()
//  Purpose:
//  Arguments:
//  Returns: 

    public String getServiceNotes() {
        return this.serviceNotes;
    }

//  Method: setexpenseName
//  Purpose:
//  Arguments:
//  Returns: 

    public void setServiceDate(LocalDateTime serviceDate) {
        this.serviceDate = serviceDate;
    }


//  Method: setexpenseDate
//  Purpose:
//  Arguments:
//  Returns: 

    public void setServiceProvided(String serviceProvided) {
        this.serviceProvided = serviceProvided;
    }

//  Method: setexpenseAmount
//  Purpose:
//  Arguments:
//  Returns: 

    public void setServiceNote(String serviceNotes) {
        this.serviceNotes = serviceNotes;
    }
}


