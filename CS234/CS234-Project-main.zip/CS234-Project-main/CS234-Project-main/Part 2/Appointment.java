import java.time.*;

public class Appointment {
    
//  Declare instance variables
    private LocalDateTime appointmentTime;
    private String serviceRequested;

//  Default constructor
    public Appointment (LocalDateTime appointmentTime, String serviceRequested) {
        modifyAppointmentTime(appointmentTime);
        modifyAppointmentService(serviceRequested);

    }

//  Method: getAppointmentTime()
//  Purpose: Get the time of the appointment
//  Arguments:  None  
//  Returns:    The appointment time as a date value

    public LocalDateTime getAppointmentTime() {
        return this.appointmentTime;
    }

//  Method: getServiceRequest()
//  Purpose: Get the service requested
//  Arguments:  None  
//  Returns:    The service requested as a string value

    public String getServiceRequested() {
        return this.serviceRequested;
    }   
  
//  Method: modifyAppointmentTime()
//  Purpose: Change the time of appointment
//  Arguments:  The time of the appointment as a date value
//  Returns:    None

    public void modifyAppointmentTime(LocalDateTime appointmentTime) {
        this.appointmentTime = appointmentTime;
    }       

//  Method: modifyAppointmentService()
//  Purpose: Change the service requested
//  Arguments:  The service requested as a string value  
//  Returns:    None

    public void modifyAppointmentService(String serviceRequested) {
        this.serviceRequested = serviceRequested;
    }    
}
