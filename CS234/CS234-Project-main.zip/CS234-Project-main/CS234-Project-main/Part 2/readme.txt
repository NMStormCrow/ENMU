To run program:
javac *.java
java GarageTest