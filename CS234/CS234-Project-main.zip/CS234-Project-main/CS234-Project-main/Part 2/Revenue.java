import java.time.LocalDateTime;

public class Revenue {

//  Instance variables
    String revenueName;
    LocalDateTime revenueDate;
    Double revenueAmount;

//  Default constructor
    public Revenue(String revenueName, LocalDateTime revenueDate, Double revenueAmount) {

        this.revenueName = revenueName;
        this.revenueDate = revenueDate;
        this.revenueAmount = revenueAmount;

    }

//  Method: showrevenueInfo()
//  Purpose: 
//  Arguments: 
//  Returns: 

public String showrevenueInfo() {
    return (this.revenueName + "\t|\t" + this.revenueDate + "\t|\t" + this.revenueAmount);
}


//  Method: getrevenueName
//  Purpose:
//  Arguments:
//  Returns: 

    public String getrevenueName() {
        return this.revenueName;
    }


//  Method: getrevenueDate
//  Purpose:
//  Arguments:
//  Returns: 

    public LocalDateTime getrevenueDate() {
        return this.revenueDate;
    }

//  Method: getrevenueAmount
//  Purpose:
//  Arguments:
//  Returns: 

    public Double getrevenueAmount() {
        return this.revenueAmount;
    }

//  Method: setrevenueName
//  Purpose:
//  Arguments:
//  Returns: 

    public void setrevenueName(String revenueName) {
        this.revenueName = revenueName;
    }


//  Method: setrevenueDate
//  Purpose:
//  Arguments:
//  Returns: 

    public void setrevenueDate(LocalDateTime revenueDate) {
        this.revenueDate = revenueDate;
    }

//  Method: setrevenueAmount
//  Purpose:
//  Arguments:
//  Returns: 

    public void setrevenueAmount(Double revenueAmount) {
        this.revenueAmount = revenueAmount;
    }


}
