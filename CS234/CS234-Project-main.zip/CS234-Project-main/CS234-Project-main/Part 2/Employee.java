

public class Employee {
    
//  Declare instance variables
    protected String employeeName;
    protected double employeeWage;
    protected double weeklyHours;

//  Method: getEmployeeName()
//  Purpose: Get the name of the employee
//  Arguments:  None  
//  Returns:    The employee name as an string value

    public String getEmployeeName() {
        return this.employeeName;
    }

//  Method: getEmployeeWage()
//  Purpose: Get the wage of the employee
//  Arguments:  None  
//  Returns:    The employee name as an double value

    public double getEmployeeWage() {
        return this.employeeWage;
    }

//  Method: setEmployeeName()
//  Purpose: Set the name of the employee
//  Arguments:  The name of the employee as a String value
//  Returns:    None

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    //  Method: setEmployeeWage()
    //  Purpose: Set the wage of the employee
    //  Arguments:  The wage of the employee as a double value
    //  Returns:    None

    public void setEmployeeWage(double employeeWage) {
        this.employeeWage = employeeWage;
    }

//  Method: setWeeklyHours()
//  Purpose: Set the weekly hours worked for employee
//  Arguments: The weekly hours worked as an arraylist of doubles
//  Returns: None

    public void setWeeklyHours(double weeklyHours) {
        this.weeklyHours = weeklyHours;
    }



//  Method: 
//  Purpose:
//  Arguments:
//  Returns: 

//  Method: 
//  Purpose:
//  Arguments:
//  Returns: 


}
