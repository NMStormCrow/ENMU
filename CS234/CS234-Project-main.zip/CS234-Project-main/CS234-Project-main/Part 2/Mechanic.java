import java.util.*;


public class Mechanic extends Employee {

//  Declare instance variables
    private ArrayList<String> mechanicVehicleCertifications = new ArrayList<String>();

//  Default constructor

    public Mechanic (String employeeName, double employeeWage, ArrayList<String> mechanicVehicleCertifications, double weeklyHours) {

        setEmployeeName(employeeName);
        setEmployeeWage(employeeWage);
        setWeeklyHours(weeklyHours);
        setMechanicVehicleCertifications(mechanicVehicleCertifications);

        
    }

//  Method: getMechanicName()
//  Purpose:
//  Arguments
//  Returns: 

    public String getMechanicName() {
        return this.employeeName;
    }

//  Method: getMechanicWage()
//  Purpose:
//  Arguments
//  Returns: 

    public double getMechanicWage() {
        return this.employeeWage;
    }

//  Method: getMechanicName()
//  Purpose:
//  Arguments
//  Returns: 

    public double getMechanicWeeklyHours() {
        return this.weeklyHours;
    }

//  Method: setMechanicName()
//  Purpose:
//  Arguments
//  Returns: 

    public void setMechanicName(String mechanicName) {
    this.employeeName = mechanicName;
    }

//  Method: setMechanicWage
//  Purpose:
//  Arguments
//  Returns: 

    public void setMechanicWage(double mechanicWage) {
        this.weeklyHours = mechanicWage;
    }

//  Method: getMechanicName()
//  Purpose:
//  Arguments
//  Returns: 

    public void  setMechanicWeeklyHours(Double weeklyHours) {
        this.weeklyHours = weeklyHours;
    }


//  Method: setMechanicVehicleCertifications()
//  Purpose:
//  Arguments
//  Returns: 

    public void setMechanicVehicleCertifications(ArrayList<String> certifications) {

        this.mechanicVehicleCertifications = certifications;
    }


//  Method: showMechanicInfo()
//  Purpose: 
//  Arguments: 
//  Returns: 

    public String showMechanicInfo() {
        return (this.employeeName + "\t|\t" + this.employeeWage + "\t|\t" + this.weeklyHours);
    }




//  Method: getMechanicVehicleCertifications()
//  Purpose: Get the vehicles the mechanic is certified on
//  Arguments: None
//  Returns: The list of vehicles the mechanic is certified on in an ArrayList of Strings

    public ArrayList<String> getMechanicVehicleCertifications() {
        return this.mechanicVehicleCertifications;
    }

//  Method: addMechanicVehicleCertification()
//  Purpose: Add a vehicle to the the list of that the mechanic is certified to work on
//  Arguments: The vehicle as a string value
//  Returns: None

    public void addMechanicVehicleCertification(String vehicle) {
        this.mechanicVehicleCertifications.add(vehicle);
    }

//  Method: removeMechanicVehicleCertification()
//  Purpose: Remove a vehicle from the the list of that the mechanic is certified to work on
//  Arguments: The vehicle as a string value
//  Returns: None

    public void removeMechanicVehicleCertification(int certificateElement) {
        this.mechanicVehicleCertifications.remove(certificateElement);
        
    }


}
