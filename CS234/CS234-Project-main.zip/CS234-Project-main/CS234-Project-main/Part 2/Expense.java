import java.time.LocalDateTime;

public class Expense {

//  Instance variables
    String expenseName;
    LocalDateTime expenseDate;
    Double expenseAmount;

//  Default constructor
    public Expense(String expenseName, LocalDateTime expenseDate, Double expenseAmount) {

        this.expenseName = expenseName;
        this.expenseDate = expenseDate;
        this.expenseAmount = expenseAmount;

    }

//  Method: showexpenseInfo()
//  Purpose: 
//  Arguments: 
//  Returns: 

public String showExpenseInfo() {
    return (this.expenseName + "\t|\t" + this.expenseDate + "\t|\t" + this.expenseAmount);
}


//  Method: getexpenseName
//  Purpose:
//  Arguments:
//  Returns: 

    public String getExpenseName() {
        return this.expenseName;
    }


//  Method: getexpenseDate
//  Purpose:
//  Arguments:
//  Returns: 

    public LocalDateTime getExpenseDate() {
        return this.expenseDate;
    }

//  Method: getexpenseAmount
//  Purpose:
//  Arguments:
//  Returns: 

    public Double getExpenseAmount() {
        return this.expenseAmount;
    }

//  Method: setexpenseName
//  Purpose:
//  Arguments:
//  Returns: 

    public void setExpenseName(String expenseName) {
        this.expenseName = expenseName;
    }


//  Method: setexpenseDate
//  Purpose:
//  Arguments:
//  Returns: 

    public void setExpenseDate(LocalDateTime expenseDate) {
        this.expenseDate = expenseDate;
    }

//  Method: setexpenseAmount
//  Purpose:
//  Arguments:
//  Returns: 

    public void setExpenseAmount(Double expenseAmount) {
        this.expenseAmount = expenseAmount;
    }


}
