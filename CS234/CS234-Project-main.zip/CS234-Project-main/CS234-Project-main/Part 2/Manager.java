import java.util.*;

public class Manager extends Employee {
    
//  Declare instance variables
    
    private ArrayList<String> managedEmployees = new ArrayList<String>();

//  Default constructor
   
    public Manager (String employeeName, double employeeWage, ArrayList<String> managedEmployees, double weeklyHours) {
        setEmployeeName(employeeName);
        setEmployeeWage(employeeWage);
        setManagedEmployees(managedEmployees);
        setWeeklyHours(weeklyHours);
    }




//  Method: showManagerInfo()
//  Purpose: 
//  Arguments: 
//  Returns: 

    public String showManagerInfo() {
        return (this.employeeName + "\t|\t" + this.employeeWage + "\t|\t" + this.weeklyHours);
    }

//  Method: getManagerName()
//  Purpose:
//  Arguments
//  Returns: 

    public String getManagerName() {
        return this.employeeName;
    }

//  Method: getManagerWage()
//  Purpose:
//  Arguments
//  Returns: 

    public double getManagerWage() {
        return this.employeeWage;
    }

//  Method: getManagerName()
//  Purpose:
//  Arguments
//  Returns: 

    public double getManagerWeeklyHours() {
        return this.weeklyHours;
    }

//  Method: setManagerName()
//  Purpose:
//  Arguments
//  Returns: 

    public void setManagerName(String managerName) {
        this.employeeName = managerName;
    }

//  Method: setManagerWage
//  Purpose:
//  Arguments
//  Returns: 

    public void setManagerWage(double managerWage) {
        this.weeklyHours = managerWage;
    }

//  Method: getMechanicName()
//  Purpose:
//  Arguments
//  Returns: 

    public void setManagerWeeklyHours(Double managerWeeklyHours) {
        this.weeklyHours = managerWeeklyHours;
    }



//  Method: getManagedEmployees()
//  Purpose: Get the employees who are managed by the manager
//  Arguments: None
//  Returns: The employees who are managed as an arraylist of Strings

    public ArrayList<String> getManagedEmployees() {
        return this.managedEmployees;
    }

//  Method: setManagedEmployees()
//  Purpose: Set the employees who are managed by the manager
//  Arguments: The employees managed as an arraylist of Strings
//  Returns: None

    public void setManagedEmployees(ArrayList<String> managedEmployees) {
        this.managedEmployees = managedEmployees;
    }

//  Method: addManagedEmloyee()
//  Purpose: Add an employee to this list of employees managed
//  Arguments: The employee's name as a string
//  Returns: None

    public void addManagedEmloyee(String employeeName) {
        managedEmployees.add(employeeName);
    }

//  Method: removeManagedEmployee()
//  Purpose: Remove an employee from the list of employees managed 
//  Arguments: The name of the employee as a string value
//  Returns: None

    public void removeManagedEmployee(int managedEmployeesElement) {
        this.managedEmployees.remove(managedEmployeesElement);
    }

}
