public class Vehicle {

//  Declare instance variables
    private String vehicleBrand;
    private String vehicleModel;
    private String vehicleYear;
    private String vehicleMileage;
    private String vehicleOwner;

//  Default constructor

    public Vehicle(String vehicleBrand, String vehicleModel, String vehicleYear, String vehicleMileage) {
        setVehicleBrand(vehicleBrand);
        setVehicleModel(vehicleModel);
        setVehicleYear(vehicleYear);
        setVehicleMileage(vehicleMileage);
        setVehicleOwner(vehicleOwner);
    }

//  Method: getVehicleBrand()
//  Purpose: Get the brand of the vehicle
//  Arguments: None
//  Returns:  The brand of the vehicle in a string value

    public String getVehicleBrand() {
        return this.vehicleBrand;
    }

//  Method: getVehicleModel()
//  Purpose: Get the model of the vehicle
//  Arguments: None
//  Returns: The model of the vehicle in a string value

    public String getVehicleModel() {
        return this.vehicleModel;
    }

//  Method: getVehicleYear()
//  Purpose: Get the year of the vehicle
//  Arguments: None
//  Returns: The year of the vehicle in a string value

    public String getVehicleYear() {
        return this.vehicleYear;
    }

//  Method: getVehicleMilage()
//  Purpose: Get the mileage of the vehicle
//  Arguments: None
//  Returns: The mileage of the vehicle as a string value

    public String getVehicleMileage() {
        return this.vehicleMileage;
    }

//  Method: getVehicleOwner()
//  Purpose: Get the owner of the vehicle
//  Arguments: None
//  Returns: The owner of the vehicle

    public String getVehicleOwner() {
        return this.vehicleOwner;
    }

//  Method: setVehicleBrand()
//  Purpose: Sets the brand of the vehicle
//  Arguments: The brand of the vehicle as a string value
//  Returns: None

    public void setVehicleBrand(String vehicleBrand) {
        this.vehicleBrand = vehicleBrand;
    }

//  Method: setVehicleModel()
//  Purpose: Sets the brand of the vehicle
//  Arguments: The brand of the vehicle as a string value
//  Returns: None

    public void setVehicleModel(String vehicleModel) {
        this.vehicleModel = vehicleModel;
    }

//  Method: setVehicleYear()
//  Purpose: Sets the year of the vehicle
//  Arguments: The year of the vehicle as a string value
//  Returns: None

    public void setVehicleYear(String vehicleYear) {
        this.vehicleYear = vehicleYear;
    }


//  Method: setVehicleMilage()
//  Purpose: Sets the milage of the vehicle
//  Arguments: The milage of the vehicle as a string value
//  Returns: None

    public void setVehicleMileage(String vehicleMileage) {
        this.vehicleMileage = vehicleMileage;
    }

//  Method: setVehicleOwner()
//  Purpose: Sets the owner of the vehicle
//  Arguments: The owner of the vehicle as a string value
//  Returns: None

    public void setVehicleOwner(String vehicleOwner) {
        this.vehicleOwner = vehicleOwner;
    }

//  Method: 
//  Purpose:
//  Arguments: 
//  Returns: 

//  Method: 
//  Purpose:
//  Arguments: 
//  Returns: 

//  Method: 
//  Purpose:
//  Arguments: 
//  Returns: 

//  Method: 
//  Purpose:
//  Arguments: 
//  Returns: 


}
