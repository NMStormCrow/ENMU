For Question #1
javac printMenu.java 
java printMenu
