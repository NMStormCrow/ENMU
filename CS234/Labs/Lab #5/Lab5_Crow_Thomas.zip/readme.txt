For Question #1
javac CustomerRewards.java 
java CustomerRewards
