For Question #1
javac [a-e]*.java
java a_SumEvenNumbers
java b_SumSquares
java c_PowerOf2
java d_SumOfOddNumbers
java e_SumOfOddDigits

For Question #2
javac Password_Tools.java 
java Password_Tools
