For Question #1
javac ComputeCostOfOrder.java
java ComputeCostOfOrder

For Question #2
javac ComputeDewPoint.java 
java ComputeDewPoint 
